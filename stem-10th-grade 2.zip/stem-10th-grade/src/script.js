document.addEventListener('DOMContentLoaded', () => {
    // 1. Setup Page Navigation
    const navLinks = document.querySelectorAll('nav a');
    const sections = document.querySelectorAll('.page');

    function showPage(id) {
        sections.forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(id).classList.add('active');
        
        // Update nav active state
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${id}`) {
                link.classList.add('active');
            }
        });
    }

    // Handles initial load and link clicks
    const initialPage = window.location.hash.substring(1) || 'home';
    showPage(initialPage);

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const pageId = e.target.getAttribute('href').substring(1);
            showPage(pageId);
        });
    });

    // --- REVISED SECTION 2: Simulate AI Upload Functionality with Smarter Diagnosis ---
    
    // Database of simulated diagnoses and tips
    const simulatedDiagnoses = [
        {
            diagnosis: "Overwatered - Leaves turning yellow and drooping.",
            tips: ["Water every 10-14 days only when the top soil is completely dry.", "Ensure the pot has proper drainage.", "Place in a bright, indirect light location."]
        },
        {
            diagnosis: "Sunburn/Heat Stress - Edges of older leaves look crispy and faded.",
            tips: ["Move to a location with morning sun and afternoon shade.", "Water deeply and consistently during hot weather.", "Apply a layer of mulch to keep the roots cool."]
        },
        {
            diagnosis: "Pest Infestation (Spider Mites) - Fine webbing visible under leaves.",
            tips: ["Wipe leaves with a damp cloth or spray with insecticidal soap.", "Increase humidity around the plant.", "Isolate the plant immediately to prevent spread."]
        }
    ];

    // Specific diagnosis for clearly unhealthy or dead plants
    const deadPlantDiagnosis = {
        diagnosis: "Severely Dehydrated/Dead - Plant is beyond recovery, completely dried out and withered.",
        tips: ["Unfortunately, this plant appears to be deceased.", "Consider starting fresh with a new plant.", "Ensure consistent watering and appropriate light for future plants."]
    };

    const healthyPlantDiagnosis = {
        diagnosis: "Healthy 🍃 - Strong stem and vibrant foliage.",
        tips: ["Continue with your current care routine.", "Check soil moisture before watering.", "Dust the leaves occasionally to maximize photosynthesis."]
    };


    const plantNameInput = document.getElementById('plant-name-input');
    const uploadInput = document.getElementById('plant-photo-upload');
    const loadingMessage = document.getElementById('loading-message');
    const aiResults = document.getElementById('ai-results');
    const ulElement = aiResults.querySelector('ul'); 

    uploadInput.addEventListener('change', function() {
        const inputName = plantNameInput.value.trim();
        const lowerCaseInputName = inputName.toLowerCase();

        if (inputName === "") {
            alert("Please type the name of your plant before uploading the photo.");
            this.value = ''; 
            return;
        }

        if (this.files && this.files[0]) {
            let selectedResult;

            // Check if the user is typing something that suggests a dead plant
            if (lowerCaseInputName.includes("dead") || lowerCaseInputName.includes("withered") || lowerCaseInputName.includes("dried")) {
                selectedResult = deadPlantDiagnosis;
            } else if (lowerCaseInputName.includes("healthy") || lowerCaseInputName.includes("perfect")) {
                selectedResult = healthyPlantDiagnosis;
            } else {
                // Pick a random result from the general diagnoses
                const resultIndex = Math.floor(Math.random() * simulatedDiagnoses.length); 
                selectedResult = simulatedDiagnoses[resultIndex];
            }


            // Simulate the upload and AI processing delay
            aiResults.style.display = 'none';
            loadingMessage.style.display = 'block';

            setTimeout(() => {
                loadingMessage.style.display = 'none';
                
                document.getElementById('plant-name-result').textContent = inputName;
                document.getElementById('plant-diagnosis-result').textContent = selectedResult.diagnosis;
                
                ulElement.innerHTML = ''; 
                selectedResult.tips.forEach(tip => {
                    const li = document.createElement('li');
                    li.textContent = tip;
                    ulElement.appendChild(li);
                });

                aiResults.style.display = 'block';
                this.value = ''; 
                plantNameInput.value = ''; 
            }, 3000); // 3 second simulation delay
        }
    });
});


// 3. Simulate Temperature Lookup Functionality (MUST BE OUTSIDE THE DOMContentLoaded BLOCK)
function getTempInfo() {
    const input = document.getElementById('plant-search-input').value.trim();
    const resultsBox = document.getElementById('temp-results');
    const searchNameSpan = document.getElementById('search-plant-name');
    const habitatSpan = document.getElementById('plant-habitat');
    const tempSpan = document.getElementById('plant-temp');

    if (input === "") {
        alert("Please enter a plant name.");
        return;
    }

    // A simple hardcoded lookup for demonstration
    const plantDatabase = {
        "lavender": {
            habitat: "Sunny, dry, well-draining soil. Mediterranean climate.",
            temp: "Ideal: 15°C - 30°C. Tolerates light frost."
        },
        "monstera": {
            habitat: "Humid, warm, indirect light. Tropical rainforest understory.",
            temp: "Ideal: 18°C - 30°C. Needs humidity above 60%."
        },
        "rose": {
            habitat: "Full sun to partial shade, rich well-draining soil. Temperate climate.",
            temp: "Ideal: 15°C - 28°C. Needs winter chill (dormancy)."
        },
        "default": {
            habitat: "Humid, sunny places.",
            temp: "Around 10°C - 20°C."
        }
    };
    
    // Normalize input for lookup
    const searchKey = input.toLowerCase();
    const data = plantDatabase[searchKey] || plantDatabase["default"];
    
    searchNameSpan.textContent = input;
    habitatSpan.textContent = data.habitat;
    tempSpan.textContent = data.temp;

    resultsBox.style.display = 'block';
}
